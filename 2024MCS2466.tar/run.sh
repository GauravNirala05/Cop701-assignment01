# Author : GAURAV NIRALA (2024MCS2466)
./latex2mdConvertor/latex2md.out $1 $2