
#ifndef TRAVERSE_H
#define TRAVERSE_H

#include<iostream>
#include "../ast_tree/ast.h"

std::string Traverse(Tree*);

#endif